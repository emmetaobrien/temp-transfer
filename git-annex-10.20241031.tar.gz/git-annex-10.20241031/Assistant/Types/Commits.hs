{- git-annex assistant commit tracking
 -
 - Copyright 2012 Joey Hess <id@joeyh.name>
 -
 - Licensed under the GNU AGPL version 3 or higher.
 -}

module Assistant.Types.Commits where

import Utility.TList

import Control.Concurrent.STM

type CommitChan = TList Commit

data Commit = Commit

newCommitChan :: IO CommitChan
newCommitChan = atomically newTList
