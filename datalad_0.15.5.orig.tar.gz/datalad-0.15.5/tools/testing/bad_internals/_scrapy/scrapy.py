raise ImportError("Scrapy import is ruined for testing")
